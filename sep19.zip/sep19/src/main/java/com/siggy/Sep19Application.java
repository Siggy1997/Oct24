package com.siggy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sep19Application {

	public static void main(String[] args) {
		SpringApplication.run(Sep19Application.class, args);
	}

}
